#include "cobullws.h"
#include <iostream>
#include <ctime>

bool check(QString s)
{
    if (s.size() != 4)
        return false;
    for (int i = 0; i < 4; i++)
        if (s[i] < '0' || s[i] > '9')
            return false;
    if (s[0] == '0')
        return false;
    int a[10] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
    for (int i = 0; i < 4; i++)
        a[s[i].toLatin1() - '0']++;
    for (int i = 0; i < 10; i++)
        if (a[i] > 1)
            return false;
    return true;
}

QString Cobullws::count(QString s)
{
    if (s.size() != 4)
        return "Неправильное число";
    for (int i = 0; i < 4; i++)
        if (s[i].toLatin1() < '0' || s[i].toLatin1() > '9')
            return "Неправильное число";
    if (s[0].toLatin1() == '0')
        return "Неправильное число";
    int a[10] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
    for (int i = 0; i < 4; i++)
        a[s[i].toLatin1() - '0']++;
    for (int i = 0; i < 10; i++)
        if (a[i] > 1)
            return "Неправильное число";

    int b = 0, c = 0, d[10] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, n1 = n, n2 = n;
    for (int i = 0; i < 4; i++)
    {

        d[n1 % 10]++;
        n1 /= 10;
    }

    for (int i = 0; i < 10; i++)
    {
        c += a[i] == 1 && d[i] == 1;
    }

    for (int i = 0; i < 4; i++)
    {
        c -= n2 % 10 == s[3 - i].toLatin1() - '0';
        b += n2 % 10 == s[3 - i].toLatin1() - '0';
        n2 /= 10;
    }

    QString ans;
    ans += QString::number(c);
    if (c == 0)
    {
        ans += " коров ";
    }
    else if (c == 1)
    {
        ans += " коров ";
    }
    else
    {
        ans += " коровы ";
    }
    ans += QString::number(b);
    if (b == 0)
    {
        ans += " быков ";
    }
    else if (b == 1)
    {
        ans += " бык ";
    }
    else
    {
        ans += " быка ";
    }

    return ans;
}

Cobullws::Cobullws(QObject *parent) : QObject(parent)
{
    fPlay = true;
    attempts = 0;
    srand(std::time(0));
    do
    {
        n = rand() % 9000 + 1000;
    }
    while (!check(QString::number(n)));
    std::cout << n << std::endl;
}

void Cobullws::setAns(QString Ans)
{
    ans = Ans;
}

void Cobullws::checkAns()
{
    if (fPlay)
    {
        if (ans == prev)
            return;
        prev = ans;
        attempts++;
        QString a = count(ans);

        if (a == "0 коров 4 быка ")
        {
            emit Out("Число угадано за " + QString::number(attempts) + "попыток");
            emit updateTxt("Новая игра");
            emit tog(false);
            fPlay = false;
        }
        else
            emit Out(count(ans));
    }
    else
    {
        fPlay = true;
        attempts = 0;
        srand(std::time(0));
        do
        {
            n = rand() % 9000 + 1000;
        }
        while (!check(QString::number(n)));
        std::cout << n << std::endl;
        emit Out("");
        emit updateTxt("Проверить");
        emit tog(true);
        emit clr();
        fPlay = true;
    }
}
