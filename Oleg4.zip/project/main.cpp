#include <QMainWindow>
#include <QApplication>
#include <QLineEdit>
#include <QPushButton>
#include <QLabel>
#include "cobullws.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    QMainWindow w;
    w.resize(179 * 2, 179 * 2);
    QLineEdit * edit = new QLineEdit(&w);
    Cobullws * cobullws = new Cobullws;
    QPushButton * check = new QPushButton(&w);
    QLabel * out = new QLabel(&w);
    QPushButton * giveup = new QPushButton(&w);
    edit->setGeometry(10, 10, 210, 30);
    check->setGeometry(10, 40, 100, 30);
    giveup->setGeometry(120, 40, 100, 30);
    out->setGeometry(10, 70, 210, 30);

    check->setText("Проверить");
    giveup->setText("Сдаться");

    QObject::connect(edit, SIGNAL(textChanged(QString)),
                     cobullws, SLOT(setAns(QString)));
    QObject::connect(cobullws, SIGNAL(Out(QString)),
                     out, SLOT(setText(QString)));
    QObject::connect(check, SIGNAL(pressed()),
                     cobullws, SLOT(checkAns()));

    QObject::connect(cobullws, &Cobullws::updateTxt,
                         check, &QPushButton::setText);
    QObject::connect(cobullws, SIGNAL(tog(bool)),
                     giveup, SLOT(setEnabled(bool)));
    QObject::connect(cobullws, SIGNAL(clr()),
                     edit, SLOT(clear()));
    w.show();
    return a.exec();
}
