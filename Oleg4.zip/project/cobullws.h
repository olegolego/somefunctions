#ifndef COUNTER_H
#define COUNTER_H

#include <QObject>


class Cobullws : public QObject
{
    Q_OBJECT
private:
    int n, attempts;
    QString ans, prev;
    QString count(QString s);
    bool fPlay;
public:
    explicit Cobullws(QObject *parent = 0);

signals:
    void Out(QString);
    void updateTxt(QString s);
    void tog(bool b);
    void clr();

public slots:
    void setAns(QString ans);
    void checkAns();
};

#endif
